conda create -n agentdemo python=3.11 -y

conda activate agentdemo

pip install -r requirements.txt
